# =====================================================================================
# coevolution_all_adaptive.py
# =====================================================================================
"""
 
Includes adaptive retraining for:
- Deep Fingerprinting (DF)
- TikTok
- Random Forest (RF)

Implements bounded attacker recovery under co-evolution.
"""

import os
import json
import numpy as np
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings("ignore")

# =====================================================================================
# PATHS & CONFIG
# =====================================================================================
BASE = os.getenv("COETA_ROOT", ".")
DATA = os.path.join(BASE, "data")
MODELS = os.path.join(BASE, "wflib", "models")
OUTPUTS = os.path.join(BASE, "outputs")

DEVICE = "cpu"
NUM_CLASSES = 95
TARGET_LEN = 5000

TRAIN_SAMPLES = 2000
VAL_SAMPLES   = 1000
TEST_SAMPLES  = 1000

BATCH = 64
LR_GEN = 1e-3
ROUNDS = 3
EPOCHS_PER_ROUND = 2
SEED = 42

np.random.seed(SEED)
torch.manual_seed(SEED)

# =====================================================================================
# GENERATOR
# =====================================================================================
class Generator(nn.Module):
    def __init__(self):
        super().__init__()
        self.c1 = nn.Conv1d(1, 8, kernel_size=15, padding=7)
        self.c2 = nn.Conv1d(8, 1, kernel_size=15, padding=7)
        self.tanh = nn.Tanh()

    def forward(self, x):
        z = torch.relu(self.c1(x))
        z = self.c2(z)
        perturb = self.tanh(z) * 0.05
        return x + perturb, perturb

# =====================================================================================
# LOSSES
# =====================================================================================
def adv_loss(model, x, y):
    return -nn.CrossEntropyLoss()(model(x), y)

def utility_loss(x, xd, p):
    return nn.MSELoss()(x, xd) + 0.1 * torch.mean(torch.abs(p))

# =====================================================================================
# ATTACKERS
# =====================================================================================
from wflib.attack.DF import DF
from wflib.attack.TikTok import TikTok

class NeuralAttacker:
    def __init__(self, cls):
        self.model = cls(num_classes=NUM_CLASSES).to(DEVICE)

    def train(self, X, y, epochs=2):
        opt = optim.Adam(self.model.parameters(), lr=1e-3)
        loader = DataLoader(TensorDataset(X, y), BATCH, shuffle=True)
        self.model.train()
        for _ in range(epochs):
            for xb, yb in loader:
                loss = nn.CrossEntropyLoss()(self.model(xb), yb)
                opt.zero_grad()
                loss.backward()
                opt.step()

    def eval(self, X, y):
        with torch.no_grad():
            return (self.model(X).argmax(1) == y).float().mean().item()

class RFAttacker:
    def __init__(self):
        self.rf = RandomForestClassifier(
            n_estimators=100, max_depth=20, random_state=42, n_jobs=-1
        )
        self.scaler = StandardScaler()

    def train(self, X, y):
        Xn = X.squeeze(1).numpy().reshape(len(X), -1)
        self.rf.fit(self.scaler.fit_transform(Xn), y.numpy())

    def eval(self, X, y):
        Xn = X.squeeze(1).numpy().reshape(len(X), -1)
        pred = self.rf.predict(self.scaler.transform(Xn))
        return (pred == y.numpy()).mean()

# =====================================================================================
# DATA LOADER
# =====================================================================================
def load_data(n, split):
    X = np.load(os.path.join(DATA, f"X_{split}.npy"))
    y = np.load(os.path.join(DATA, f"y_{split}.npy"))
    idx = np.random.choice(len(X), n, replace=False)
    X = X[idx].astype(np.float32)
    y = y[idx].astype(np.int64)
    for i in range(len(X)):
        X[i] = (X[i] - X[i].mean()) / (X[i].std() + 1e-8)
    X = X[:, :TARGET_LEN][:, None, :]
    return torch.tensor(X), torch.tensor(y)

# =====================================================================================
# MAIN CO-EVOLUTION
# =====================================================================================
def main():
    Xtr, ytr = load_data(TRAIN_SAMPLES, "train")
    Xv,  yv  = load_data(VAL_SAMPLES,   "train")
    Xt,  yt  = load_data(TEST_SAMPLES,  "test")

    gen = Generator().to(DEVICE)
    opt = optim.Adam(gen.parameters(), lr=LR_GEN)

    results = []

    for r in range(ROUNDS):
        print(f"\n================ ROUND {r+1} =================")

        # -------- DEFENDED DATA --------
        with torch.no_grad():
            Xtr_d, _ = gen(Xtr)
            Xv_d,  _ = gen(Xv)
            Xt_d,  _ = gen(Xt)

        # -------- ADAPTIVE ATTACKERS --------
        df = NeuralAttacker(DF)
        tk = NeuralAttacker(TikTok)
        rf = RFAttacker()

        df.train(Xtr_d, ytr)
        tk.train(Xtr_d, ytr)
        rf.train(Xtr_d, ytr)

        df_val = df.eval(Xv_d, yv)
        tk_val = tk.eval(Xv_d, yv)
        rf_val = rf.eval(Xv_d, yv)

        df_test = df.eval(Xt_d, yt)
        tk_test = tk.eval(Xt_d, yt)
        rf_test = rf.eval(Xt_d, yt)

        print(f"DF  adaptive: val={df_val:.3f}, test={df_test:.3f}")
        print(f"TK  adaptive: val={tk_val:.3f}, test={tk_test:.3f}")
        print(f"RF  adaptive: val={rf_val:.3f}, test={rf_test:.3f}")

        results.append({
            "round": r+1,
            "DF": {"val": df_val, "test": df_test},
            "TikTok": {"val": tk_val, "test": tk_test},
            "RF": {"val": rf_val, "test": rf_test},
        })

        # -------- UPDATE GENERATOR --------
        gen.train()
        loader = DataLoader(TensorDataset(Xtr, ytr), BATCH, shuffle=True)
        for _ in range(EPOCHS_PER_ROUND):
            for xb, yb in loader:
                xd, p = gen(xb)
                loss = (
                    adv_loss(df.model, xd, yb)
                    + adv_loss(tk.model, xd, yb)
                    + 0.5 * utility_loss(xb, xd, p)
                )
                opt.zero_grad()
                loss.backward()
                opt.step()

    # -------- SAVE --------
    with open(os.path.join(OUTPUTS, "adaptive_all_attackers.json"), "w") as f:
        json.dump(results, f, indent=2)

    print("\n✓ CO-EVOLUTION COMPLETE (DF + TikTok + RF)")

if __name__ == "__main__":
    main()
