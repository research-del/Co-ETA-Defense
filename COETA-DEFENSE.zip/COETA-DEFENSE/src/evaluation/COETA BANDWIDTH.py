======================================================
# BANDWIDTH OVERHEAD (MAX-LENGTH PADDING VERSION)
# 
# ======================================================

import os
import numpy as np

BASE = os.getenv("COETA_ROOT", ".")
DATA = os.path.join(BASE, "data")

TARGET_LEN = 5000
NUM_SAMPLES = 5000

# Load raw traces
X = np.load(os.path.join(DATA, "X_test.npy"), mmap_mode="r")
idx = np.random.choice(len(X), NUM_SAMPLES, replace=False)
X = X[idx]

orig_lengths = []
def_lengths = []

for trace in X:
    # Original packet count (non-zero packets)
    orig_len = np.count_nonzero(trace)
    orig_lengths.append(orig_len)

    # Defended trace is padded to TARGET_LEN
    def_lengths.append(TARGET_LEN)

orig_avg = np.mean(orig_lengths)
def_avg = np.mean(def_lengths)

bandwidth_overhead = (def_avg - orig_avg) / orig_avg * 100

print("=========== BANDWIDTH OVERHEAD ===========")
print(f"Average original packets : {orig_avg:.1f}")
print(f"Average defended packets : {def_avg:.1f}")
print(f"Bandwidth overhead (%)   : {bandwidth_overhead:.2f}%")
