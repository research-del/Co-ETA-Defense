# ======================================================
# CLOSED-WORLD EVALUATION  
# ======================================================

import numpy as np
import torch
from sklearn.metrics import accuracy_score

# --------------------------
# CONFIG
# --------------------------
DEVICE = "cpu"
NUM_CLASSES = 95
BATCH = 8  # Small batch for quick demo

# --------------------------
# LOAD DATA (DUMMY EXAMPLE)
# --------------------------
# Replace with dataset for real results
# Example:
# X = np.load("path/to/X_test.npy").astype(np.float32)
# y = np.load("path/to/y_test.npy")

# Dummy dataset for demo
X = np.random.randn(20, 1, 5000).astype(np.float32)
y = np.random.randint(0, NUM_CLASSES, size=(20,))

# --------------------------
# LOAD DEFENSE (DUMMY GENERATOR)
# --------------------------
# Replace with generator class and checkpoint
# from coevolution_training import PaperReadyGenerator
# generator = PaperReadyGenerator().to(DEVICE)
# ckpt = torch.load("path/to/paper_ready_generator.pth", map_location=DEVICE)
# generator.load_state_dict(ckpt["state_dict"])
# generator.eval()

class DummyGenerator:
    def eval(self):
        return self
    def __call__(self, xb):
        # Returns "defended" version (unchanged for demo) and placeholder
        return xb, None

generator = DummyGenerator()

# --------------------------
# LOAD ATTACKERS (DUMMY MODELS)
# --------------------------
# Replace with your own trained models
# from wflib.attack.DF import DF
# from wflib.attack.TikTok import TikTok
# import joblib
# df = DF(num_classes=NUM_CLASSES).to(DEVICE)
# df.load_state_dict(torch.load("path/to/DF.pth", map_location=DEVICE))
# df.eval()
# tk = TikTok(num_classes=NUM_CLASSES).to(DEVICE)
# tk.load_state_dict(torch.load("path/to/TikTok.pth", map_location=DEVICE))
# tk.eval()
# rf = joblib.load("path/to/RF.pkl")

class DummyModel:
    def eval(self):
        return self
    def __call__(self, xb):
        batch_size = xb.shape[0]
        # Return random logits for demo
        return torch.tensor(np.random.randn(batch_size, NUM_CLASSES), dtype=torch.float32)

df = DummyModel()
tk = DummyModel()
rf = None  # Placeholder for Random Forest

# --------------------------
# EVALUATION FUNCTIONS
# --------------------------
def eval_neural(model):
    """Evaluate neural network attacker on defended traces."""
    preds = []
    for i in range(0, len(X), BATCH):
        xb = torch.tensor(X[i:i+BATCH]).to(DEVICE)
        with torch.no_grad():
            defended, _ = generator(xb)
            p = model(defended).argmax(1).cpu().numpy()
        preds.append(p)
    preds = np.concatenate(preds)
    return accuracy_score(y, preds)

def eval_rf():
    """Evaluate Random Forest attacker (dummy)."""
    # Replace with your own RF evaluation
    # X_flat = X.reshape(len(X), -1)
    # return (rf.predict(X_flat) == y).mean()
    return np.random.rand()  # Dummy accuracy for demo

# --------------------------
# RUN EVALUATION
# --------------------------
print("\n=== CLOSED-WORLD EVALUATION (FROZEN DEFENSE) ===")
print(f"DF accuracy:     {eval_neural(df):.3f}")
print(f"TikTok accuracy: {eval_neural(tk):.3f}")
print(f"RF accuracy:     {eval_rf():.3f}")

# --------------------------
# INSTRUCTIONS FOR REVIEWERS
# --------------------------
"""
To reproduce actual results:
1. Replace X and y with your test dataset.
2. Replace DummyGenerator with your trained defense generator.
3. Replace DummyModel with trained DF, TikTok, and RF models.
4. Ensure batch size and DEVICE match your environment.
"""
