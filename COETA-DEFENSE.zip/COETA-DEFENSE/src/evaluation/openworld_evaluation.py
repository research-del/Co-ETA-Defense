# ======================================================
# ARTA OPEN-WORLD EVALUATION (DF / TikTok / RF)
# Batch-safe + RF tuple fix + Threshold tuning
# ======================================================

import os
import numpy as np
import torch
import joblib
from sklearn.metrics import accuracy_score

from wflib.attack.DF import DF
from wflib.attack.TikTok import TikTok

# ======================================================
# CONFIG
# ======================================================
BASE = os.getenv("COETA_ROOT", ".")
DATA = os.path.join(BASE, "data", "open_world_defended")
MODELS = os.path.join(BASE, "wflib", "models")

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH = 128
NUM_CLASSES = 95
UNMON_LABEL = -1

# ======================================================
# LOAD DEFENDED OPEN-WORLD DATA
# ======================================================
X = np.load(os.path.join(DATA, "X_test_def_open.npy")).astype(np.float32)
y = np.load(os.path.join(DATA, "y_test_open.npy"))

mon_mask = (y != UNMON_LABEL)
unmon_mask = (y == UNMON_LABEL)

print("✓ Defended OW data loaded")
print("  Total:", len(X))
print("  Monitored:", mon_mask.sum())
print("  Unmonitored:", unmon_mask.sum())

# ======================================================
# LOAD ATTACKERS
# ======================================================
df = DF(num_classes=NUM_CLASSES).to(DEVICE)
df.load_state_dict(torch.load(os.path.join(MODELS, "DF.pth"), map_location=DEVICE))
df.eval()
print("✓ DF loaded")

tk = TikTok(num_classes=NUM_CLASSES).to(DEVICE)
tk.load_state_dict(torch.load(os.path.join(MODELS, "TikTok.pth"), map_location=DEVICE))
tk.eval()
print("✓ TikTok loaded")

rf_loaded = joblib.load(os.path.join(MODELS, "RF.pkl"))
rf = rf_loaded[0] if isinstance(rf_loaded, tuple) else rf_loaded
print("✓ RF loaded (joblib)")

# ======================================================
# OPEN-WORLD EVALUATION FUNCTION
# ======================================================
def eval_attacker(name, model, conf_thresh):
    preds = []

    for i in range(0, len(X), BATCH):
        xb = X[i:i+BATCH]

        if name == "RF":
            xb_flat = xb.reshape(len(xb), -1)
            probs = model.predict_proba(xb_flat)
            max_probs = probs.max(axis=1)
            p = probs.argmax(axis=1)
            p[max_probs < conf_thresh] = UNMON_LABEL
        else:
            with torch.no_grad():
                xt = torch.tensor(xb).float().to(DEVICE)
                logits = model(xt)
                probs = torch.softmax(logits, dim=1).cpu().numpy()
                max_probs = probs.max(axis=1)
                p = probs.argmax(axis=1)
                p[max_probs < conf_thresh] = UNMON_LABEL

        preds.append(p)

    preds = np.concatenate(preds)

    # Metrics
    acc_mon = accuracy_score(y[mon_mask], preds[mon_mask])
    fpr = np.mean(preds[unmon_mask] != UNMON_LABEL)
    return acc_mon, fpr, preds

# ======================================================
# AUTOMATIC THRESHOLD TUNING
# ======================================================
def tune_threshold(name, model, conf_range, target_fpr=0.1):
    best_thresh = conf_range[0]
    best_acc = 0.0
    for t in conf_range:
        acc, fpr, _ = eval_attacker(name, model, conf_thresh=t)
        if fpr <= target_fpr and acc > best_acc:
            best_acc = acc
            best_thresh = t
    print(f">> {name} best threshold: {best_thresh:.3f}, monitored acc: {best_acc:.4f}")
    return best_thresh

# Define search ranges per attacker
CONF_SEARCH = {
    "DF": np.linspace(0.01, 0.2, 20),
    "TikTok": np.linspace(0.01, 0.2, 20),
    "RF": np.linspace(0.3, 0.9, 20)
}

# ======================================================
# RUN EVALUATION
# ======================================================
results = {}
best_thresholds = {}

for name, model in [("DF", df), ("TikTok", tk), ("RF", rf)]:
    # Tune threshold automatically
    best_thresh = tune_threshold(name, model, CONF_SEARCH[name], target_fpr=0.1)
    best_thresholds[name] = best_thresh
    acc_mon, fpr, _ = eval_attacker(name, model, conf_thresh=best_thresh)
    results[name] = (acc_mon, fpr)

print("\n=== OPEN-WORLD EVALUATION COMPLETE ===")
for name in results:
    print(f"{name} | Monitored Acc: {results[name][0]:.4f} | FPR: {results[name][1]:.4f}")
