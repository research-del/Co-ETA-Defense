# ======================================================
# OPEN-WORLD PRECISION–RECALL CURVES (DF / TikTok / RF)
# ARTA-defended traffic
# ======================================================

import os
import numpy as np
import torch
import joblib
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve, average_precision_score

from wflib.attack.DF import DF
from wflib.attack.TikTok import TikTok

# ======================================================
# CONFIG
# ======================================================
BASE = os.getenv("COETA_ROOT", ".")
DATA = os.path.join(BASE, "data", "open_world_defended")
MODELS = os.path.join(BASE, "wflib", "models")

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
BATCH = 128
NUM_CLASSES = 95
UNMON_LABEL = -1

# ======================================================
# LOAD DATA
# ======================================================
X = np.load(os.path.join(DATA, "X_test_def_open.npy")).astype(np.float32)
y = np.load(os.path.join(DATA, "y_test_open.npy"))

# Binary labels: monitored = 1, unmonitored = 0
y_binary = (y != UNMON_LABEL).astype(int)

print("✓ Data loaded")
print("  Monitored:", y_binary.sum())
print("  Unmonitored:", len(y_binary) - y_binary.sum())

# ======================================================
# LOAD ATTACKERS
# ======================================================
df = DF(num_classes=NUM_CLASSES).to(DEVICE)
df.load_state_dict(torch.load(os.path.join(MODELS, "DF.pth"), map_location=DEVICE))
df.eval()

tk = TikTok(num_classes=NUM_CLASSES).to(DEVICE)
tk.load_state_dict(torch.load(os.path.join(MODELS, "TikTok.pth"), map_location=DEVICE))
tk.eval()

rf_loaded = joblib.load(os.path.join(MODELS, "RF.pkl"))
rf = rf_loaded[0] if isinstance(rf_loaded, tuple) else rf_loaded

# ======================================================
# GET CONFIDENCE SCORES
# ======================================================
def get_scores(attacker_name, model):
    scores = []

    for i in range(0, len(X), BATCH):
        xb = X[i:i+BATCH]

        if attacker_name == "RF":
            xb_flat = xb.reshape(len(xb), -1)
            probs = model.predict_proba(xb_flat)
            score = probs.max(axis=1)   # confidence
        else:
            with torch.no_grad():
                xt = torch.tensor(xb).float().to(DEVICE)
                logits = model(xt)
                probs = torch.softmax(logits, dim=1).cpu().numpy()
                score = probs.max(axis=1)

        scores.append(score)

    return np.concatenate(scores)

# ======================================================
# COMPUTE PR CURVES
# ======================================================
scores_df = get_scores("DF", df)
scores_tk = get_scores("TikTok", tk)
scores_rf = get_scores("RF", rf)

pr_df = precision_recall_curve(y_binary, scores_df)
pr_tk = precision_recall_curve(y_binary, scores_tk)
pr_rf = precision_recall_curve(y_binary, scores_rf)

ap_df = average_precision_score(y_binary, scores_df)
ap_tk = average_precision_score(y_binary, scores_tk)
ap_rf = average_precision_score(y_binary, scores_rf)

# ======================================================
# PLOT
# ======================================================
plt.figure(figsize=(7, 5))

plt.plot(pr_df[1], pr_df[0], label=f"DF (AP={ap_df:.3f})")
plt.plot(pr_tk[1], pr_tk[0], label=f"TikTok (AP={ap_tk:.3f})")
plt.plot(pr_rf[1], pr_rf[0], label=f"RF (AP={ap_rf:.3f})")

plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Open-World Precision–Recall Curves (ARTA-defended)")
plt.legend()
plt.grid(True)
plt.tight_layout()

plt.savefig("ow_precision_recall_curves.pdf", dpi=300)
plt.show()

print("✓ Precision–Recall curves generated and saved")
